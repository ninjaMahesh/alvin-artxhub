<?php
namespace Braintree;

/**
 * @property-read string $name
 * @property-read string $phone
 * @property-read string $url
 */
class Descriptor extends Instance
{
}
